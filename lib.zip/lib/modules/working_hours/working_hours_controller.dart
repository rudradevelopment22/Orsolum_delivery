import 'package:get/get.dart';

class WorkingHoursController extends GetxController {}
