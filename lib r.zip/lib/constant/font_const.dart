abstract class FontConst{
  static String bowlby = "BowlbyOneSC";
  static String plusJakarSans = "PlusJakartaSans";
}