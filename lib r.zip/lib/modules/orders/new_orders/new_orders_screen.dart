import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import 'package:orsolum_delivery/common/online_toggle.dart';
import 'package:orsolum_delivery/common/order_widget.dart';
import 'package:orsolum_delivery/modules/orders/new_orders/new_order_controller.dart';

class NewOrdersScreen extends GetView<NewOrderController> {
  const NewOrdersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text("New Orders"),
        actions: [OnlineToggle()],
        actionsPadding: EdgeInsets.only(right: 10),
        elevation: 1,
      ),
      body: Padding(
        padding: EdgeInsetsGeometry.symmetric(horizontal: 16),
        child: ListView.separated(
          itemBuilder: (context, index) {
            return OrderWidget();
          },
          separatorBuilder: (context, index) => const Gap(10),
          itemCount: 3,
        ),
      ),
    );
  }
}
