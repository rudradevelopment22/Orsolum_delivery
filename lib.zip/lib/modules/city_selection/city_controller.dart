import 'package:get/get.dart';

class CityController extends GetxController {}
