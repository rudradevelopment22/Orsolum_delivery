import 'package:get/get.dart';

class NewOrderController extends GetxController {}
