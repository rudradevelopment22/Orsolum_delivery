abstract class Const{
  static String appName = "Orsolum";
}