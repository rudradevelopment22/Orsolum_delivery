import 'package:get/get.dart';
import 'package:orsolum_delivery/api/api.dart';
import 'package:orsolum_delivery/api/api_const.dart';
import 'package:orsolum_delivery/models/order_model.dart';

class NewOrderController extends GetxController {
  // Observable variables
  final RxList<OrderModel> orders = <OrderModel>[].obs;
  final RxBool isLoading = false.obs;
  final RxString errorMessage = ''.obs;

  @override
  void onInit() {
    super.onInit();
    fetchNewOrders();
  }

  // Fetch new orders from API
  Future<void> fetchNewOrders() async {
    try {
      isLoading.value = true;
      errorMessage.value = '';

      final response = await Api.client.get<OrderModel>(
        endPoint: ApiConst.newOrders,
      );

      if (response == 200) {
        if (response.data is List) {
          orders.assignAll(
            (response.data as List)
                .map((order) => OrderModel.fromJson(order))
                .toList(),
          );
        } else {
          // Handle single order case
          orders.assignAll([
            OrderModel.fromJson(response.data as Map<String, dynamic>),
          ]);
        }
      } else {
        errorMessage.value = response.message ?? 'Failed to fetch orders';
      }
    } catch (e) {
      errorMessage.value = 'Error: ${e.toString()}';
    } finally {
      isLoading.value = false;
    }
  }

  // Refresh orders
  Future<void> refreshOrders() async {
    await fetchNewOrders();
  }

  // Accept order
  Future<void> acceptOrder(String orderId) async {
    try {
      // You can implement accept order API call here
      // For now, just remove from the list
      orders.removeWhere((order) => order.id == orderId);
      Get.snackbar('Success', 'Order accepted successfully');
    } catch (e) {
      Get.snackbar('Error', 'Failed to accept order: ${e.toString()}');
    }
  }

  // Reject order
  Future<void> rejectOrder(String orderId) async {
    try {
      // You can implement reject order API call here
      // For now, just remove from the list
      orders.removeWhere((order) => order.id == orderId);
      Get.snackbar('Success', 'Order rejected');
    } catch (e) {
      Get.snackbar('Error', 'Failed to reject order: ${e.toString()}');
    }
  }
}
