class HomeResModel {}
